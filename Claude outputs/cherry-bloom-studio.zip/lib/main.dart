import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

// App publica de Cherry Bloom Studio: envuelve el sitio web ya desplegado
// en Vercel dentro de una app nativa de Android. No hay logica propia aqui
// a proposito -- todo (catalogo, cotizar, contacto) vive en el sitio web,
// para no duplicar mantenimiento entre la web y la app.
const String kSiteUrl = 'https://cherry-bloom-studio-web-omega.vercel.app';

void main() {
  runApp(const CherryBloomApp());
}

class CherryBloomApp extends StatelessWidget {
  const CherryBloomApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cherry Bloom Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.pink),
      home: const WebViewScreen(url: kSiteUrl),
    );
  }
}

class WebViewScreen extends StatefulWidget {
  final String url;
  const WebViewScreen({super.key, required this.url});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => _loading = true),
          onPageFinished: (_) => setState(() => _loading = false),
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  // Antes de cerrar la app con el boton "atras" de Android, si se puede
  // retroceder dentro del sitio (por ejemplo saliendo de /cotizar hacia el
  // catalogo), lo hacemos ahi primero.
  Future<void> _handleBack(bool didPop) async {
    if (didPop) return;
    final canGoBack = await _controller.canGoBack();
    if (canGoBack) {
      await _controller.goBack();
    } else if (mounted) {
      Navigator.of(context).maybePop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) => _handleBack(didPop),
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_loading) const Center(child: CircularProgressIndicator()),
            ],
          ),
        ),
      ),
    );
  }
}
