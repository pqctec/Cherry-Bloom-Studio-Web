# Cherry Bloom Studio — app de iPhone (proyecto Xcode)

Esta carpeta es un proyecto de Capacitor: envuelve tu web pública
(https://cherry-bloom-studio-web-omega.vercel.app) dentro de una app nativa
de iPhone. No duplica el sitio — lo muestra en vivo, así que cualquier
cambio que hagas en la web se refleja automáticamente en la app, sin volver
a compilar nada.

## Lo que necesitas en tu Mac (una sola vez)

1. **Xcode** — desde la App Store (gratis).
2. **CocoaPods** — abre Terminal y corre:
   ```
   sudo gem install cocoapods
   ```
3. **Node.js** — si no lo tienes, instálalo desde https://nodejs.org (o `brew install node`).

## Pasos

1. Descomprime esta carpeta donde quieras en tu Mac (por ejemplo, en Documentos).
2. Abre Terminal y entra a la carpeta:
   ```
   cd ~/Documents/CherryBloomStudio-iOS
   npm install
   npx cap sync ios
   ```
3. Instala las dependencias nativas:
   ```
   cd ios/App
   pod install
   cd ../..
   ```
4. Abre el proyecto **en el archivo `.xcworkspace`** (no el `.xcodeproj`):
   ```
   open ios/App/App.xcworkspace
   ```
5. En Xcode, click en el ícono del proyecto "App" en el panel izquierdo →
   pestaña **Signing & Capabilities** → en **Team**, elige tu cuenta de Apple
   (tu Apple ID debe estar agregado en Xcode → Settings → Accounts; si no
   tienes cuenta de Apple Developer todavía, puedes probar la app en tu
   propio iPhone gratis con un Apple ID normal, con la limitación de que
   hay que reinstalarla cada 7 días).
6. Conecta tu iPhone por cable (o elige un simulador arriba) y dale al botón
   ▶ Run. La app debería abrir y cargar tu web.

## Para subirla al App Store (cuando quieras)

Necesitas una cuenta de **Apple Developer Program** (99 USD/año, la creas y
pagas tú en https://developer.apple.com/programs/ — es tu cuenta, tu tarjeta,
tu identidad legal, así que este paso lo tienes que hacer tú). Con esa
cuenta ya vinculada en Xcode:

1. Product → Archive
2. En el Organizer que se abre, "Distribute App" → App Store Connect → Upload
3. Completas la ficha de la app en https://appstoreconnect.apple.com (nombre,
   capturas de pantalla, descripción, categoría, copyright, etc.)
4. Apple revisa la app (normalmente 1–3 días) y, si la aprueban, queda
   publicada.

## Si más adelante cambias de dominio

Solo edita la línea `url:` en `capacitor.config.ts`, y vuelve a correr
`npx cap sync ios`. No hace falta tocar nada más.

## Ícono y nombre

El ícono ya está generado a partir de tu logo real. El nombre que verás bajo
el ícono en el iPhone es "Cherry Bloom Studio". El copyright en
`Info.plist` quedó como "© 2026 Cherry Bloom Studio" — cuando definas cómo
quieres aparecer como autor/titular, dile a Claude tu nombre (personal o
razón social) y te dejo ese dato corregido en ambas apps.
