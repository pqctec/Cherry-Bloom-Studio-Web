# Cherry Bloom Gestión — app nativa de tu ERP (iPhone y Android)

Trae `ios/` y `android/` listos. Abre directo tu panel de administración
(https://cherry-bloom-studio-web-omega.vercel.app/admin) dentro de una app
nativa — usas el mismo usuario y clave que ya tienes, no es una cuenta
aparte.

## Android (en tu misma PC, sin Mac)

1. Instala Android Studio (https://developer.android.com/studio) si no lo
   tienes.
2. Descomprime esta carpeta, abre Android Studio → "Open" → elige la
   carpeta `android` de aquí adentro.
3. Espera a que sincronice.
4. Conecta tu celular (con Depuración USB activada) o usa un emulador.
5. ▶ Run.

## iPhone (necesita Mac)

```
npm install
npx cap sync ios
cd ios/App && pod install && cd ../..
open ios/App/App.xcworkspace
```
Luego en Xcode: Signing & Capabilities → Team → tu cuenta de Apple → ▶ Run.

## Importante: es tu panel interno

No tiene sentido subir esta app a Google Play ni al App Store público —
cualquiera podría descargarla, aunque igual necesitaría tu usuario y clave
para entrar. Lo normal es quedarte con la app instalada solo en tu celular
(o el de algún empleado de confianza) directo desde Android
Studio/Xcode, sin pasar por las tiendas. Si más adelante quieres repartirla
a varios celulares sin pasar por Play Store/App Store, existen opciones de
distribución interna (Google Play tiene "Internal testing" gratis y es
bastante simple; Apple es más restrictivo) — avísame cuando llegue el
momento y lo vemos.
