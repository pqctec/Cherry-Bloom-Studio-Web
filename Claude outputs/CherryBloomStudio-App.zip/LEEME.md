# Cherry Bloom Studio — app nativa (iPhone y Android)

Esta carpeta trae **un solo proyecto** con las dos plataformas listas:
`ios/` (para iPhone, se compila en Mac) y `android/` (para Android, se
compila en Windows, Mac o Linux). Ambas muestran tu web pública
(https://cherry-bloom-studio-web-omega.vercel.app) dentro de una app nativa
— no duplican el sitio, lo cargan en vivo, así que cualquier cambio que
hagas en la web se ve automáticamente en la app, sin recompilar nada.

---

## Android (más simple — no necesita Mac, lo puedes hacer en tu misma PC)

### Lo que necesitas (una sola vez)

1. **Android Studio** — descárgalo gratis de https://developer.android.com/studio
   e instálalo. Al abrirlo la primera vez te va a pedir instalar el SDK de
   Android — dile que sí a todo lo que sugiere por defecto.

### Pasos

1. Descomprime esta carpeta en tu PC.
2. Abre Android Studio → "Open" → selecciona la carpeta `android` que está
   dentro de este proyecto (`.../CherryBloomStudio/android`).
3. Espera a que termine de sincronizar (la primera vez tarda varios
   minutos, descarga cosas).
4. Conecta tu celular Android por USB (con "Depuración USB" activada en
   Ajustes → Opciones de desarrollador) o usa un emulador desde el mismo
   Android Studio.
5. Dale al botón ▶ Run.

### Para publicarla en Google Play (cuando quieras)

Necesitas una cuenta de **Google Play Console** (pago único de 25 USD, la
creas y pagas tú en https://play.google.com/console — es tu cuenta, tu
identidad). Con eso:

1. Build → Generate Signed Bundle / APK → sigues el asistente (crea tu
   propia "keystore", que es como la llave que firma tus apps — guárdala
   bien, la necesitas para toda actualización futura).
2. Subes el `.aab` generado a Play Console, completas la ficha (capturas,
   descripción, categoría, política de privacidad) y envías a revisión.

---

## iPhone (necesita una Mac)

Ver los pasos completos más abajo — son los mismos que ya conoces si
llegaste desde la otra conversación. En resumen, en tu Mac:

```
npm install
npx cap sync ios
cd ios/App && pod install && cd ../..
open ios/App/App.xcworkspace
```

Luego, en Xcode: Signing & Capabilities → Team → tu cuenta de Apple → ▶ Run.

Para App Store necesitas la cuenta de Apple Developer Program (99 USD/año,
la pagas tú), y desde Xcode: Product → Archive → Distribute App.

---

## Ícono, nombre y copyright

El ícono ya está generado a partir de tu logo real, en todas las
resoluciones que piden iOS y Android. El nombre visible es
"Cherry Bloom Studio". El copyright quedó como placeholder
"© 2026 Cherry Bloom Studio" — dile a Claude tu nombre (personal o razón
social) cuando lo tengas decidido y te lo corrige en ambas apps y en la web.

## Si cambias de dominio

Edita la línea `url:` en `capacitor.config.ts` (en la raíz de esta carpeta)
y vuelve a correr `npx cap sync`. No hace falta tocar nada más en ninguna
de las dos plataformas.
