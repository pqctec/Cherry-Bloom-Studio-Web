# Cherry Bloom Gestión — app de iPhone (proyecto Xcode)

Esta es tu app de ERP: abre directo el panel de administración
(https://cherry-bloom-studio-web-omega.vercel.app/admin) dentro de una app
nativa de iPhone. Usa el mismo usuario y clave que ya usas para entrar al
panel desde el navegador — no es una cuenta aparte.

Los pasos para compilarla en tu Mac son exactamente los mismos que para la
app "Cherry Bloom Studio" (ver `LEEME-XCODE.md` de esa carpeta), solo que
aquí trabajas dentro de esta carpeta (`CherryBloomGestion-iOS`) en vez de la
otra. En resumen:

1. Descomprime esta carpeta en tu Mac.
2. Terminal:
   ```
   cd ~/Documents/CherryBloomGestion-iOS
   npm install
   npx cap sync ios
   cd ios/App && pod install && cd ../..
   open ios/App/App.xcworkspace
   ```
3. En Xcode: Signing & Capabilities → Team → tu cuenta de Apple.
4. ▶ Run en tu iPhone o el simulador.

Recomendación: instala primero "Cherry Bloom Studio" (la pública) siguiendo
su propio LEEME, así ya tienes CocoaPods y Xcode configurados — para esta
segunda app el proceso es mucho más rápido.

## Importante: es tu panel interno

Como esta app abre tu ERP, no tiene sentido subirla al App Store público —
cualquiera podría descargarla e intentar entrar (aunque necesitarían tu
usuario y clave). Lo normal es quedarte con la app instalada solo en tu
iPhone (paso 4 de arriba) sin pasar por App Store. Si en algún momento
quieres compartirla con más empleados desde sus propios iPhones sin pasar
por el App Store público, avísame — existe una opción (Apple Business
Manager / distribución interna) pero también tiene sus propios requisitos
y costos, y podemos revisarla cuando llegue el momento.
